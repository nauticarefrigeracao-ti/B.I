import sqlite3
from pathlib import Path
import pandas as pd
import streamlit as st
from datetime import datetime
import importlib.util
import html
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, Alignment, numbers

DT_CSS = "https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css"
DT_JS = "https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"
JQ = "https://code.jquery.com/jquery-3.5.1.js"

def render_interactive_table(df, table_id='tbl'):
    """Return HTML snippet for an interactive DataTable (client-side)."""
    if df is None or df.empty:
        return '<div>(vazio)</div>'
    # sanitize column names and values
    df2 = df.copy()
    # convert datetimes
    for c in df2.select_dtypes(include=['datetime', 'datetimetz']).columns:
        df2[c] = df2[c].dt.strftime('%Y-%m-%d %H:%M:%S').fillna('')
    # allow HTML (we will insert small markup for highlighting)
    html_table = df2.fillna('').to_html(index=False, table_id=table_id, classes='display', escape=False)

    # build HTML with DataTables init and light CSS
    css = DT_CSS
    jq = JQ
    dtjs = DT_JS
    css_block = '<style>.neg {{ color: #c62828; font-weight: 600; }} .rev {{ color: #2e7d32; font-weight: 700; }}</style>'
    safe = (
    f'<link rel="stylesheet" href="{css}">'
    + f'<script src="{jq}"></script>'
    + f'<script src="{dtjs}"></script>'
    + css_block
    + f'<div style="max-height:520px; overflow:auto">{html_table}</div>'
    + f'<script>$(document).ready(function(){{$("#{table_id}").DataTable({{"pageLength":25, "lengthMenu":[10,25,50,100]}});}});</script>'
    )
    return safe

DB_PATH = Path('ml_devolucoes.db')

@st.cache_data
def get_months():
    con = sqlite3.connect(DB_PATH)
    df = pd.read_sql("SELECT DISTINCT substr(data_venda,1,7) as ym FROM orders ORDER BY ym DESC", con)
    con.close()
    months = df['ym'].dropna().tolist()
    return months

@st.cache_data
def load_financials(month=None, only_pending=False, sku_filter=None):
    con = sqlite3.connect(DB_PATH)
    q = 'SELECT o.order_id, o.data_venda, o.total_brl, o._valor_passivel_extorno, o._valor_pendente, o.dinheiro_liberado, oi.sku, oi.preco_unitario, oi.unidades, o.resultado, o.mes_faturamento FROM orders o JOIN order_items oi ON o.order_id=oi.order_id'
    filters = []
    if month:
        filters.append(f"substr(o.data_venda,1,7) = '{month}'")
    if only_pending:
        filters.append('o._valor_pendente > 0')
    if sku_filter:
        # simple like
        filters.append(f"oi.sku LIKE '%{sku_filter}%'")
    if filters:
        q += ' WHERE ' + ' AND '.join(filters)
    q += ' ORDER BY o._valor_pendente DESC'
    df = pd.read_sql(q, con)
    con.close()
    # post-process types
    if 'data_venda' in df.columns:
        df['data_venda'] = pd.to_datetime(df['data_venda'], errors='coerce')
    numeric_cols = ['total_brl', '_valor_passivel_extorno', '_valor_pendente', 'dinheiro_liberado', 'preco_unitario']
    for c in numeric_cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0.0)
    # Derived columns for clearer business semantics
    # 'prejuizo_real_signed' = signed total (negative when the order is a net loss)
    # 'prejuizo_real' = absolute magnitude of that prejudice (positive number)
    # 'prejuizo_pendente_calc' = magnitude still pending (>=0)
    # 'prejuizo_pendente_signed' = signed pending amount (negative when there is an outstanding loss)
    if 'total_brl' in df.columns:
        # "Prejuízo" should reflect the signed total reported by Mercado Livre
        # i.e. negative when the net result is a loss. Keep an explicit field
        # for UI convenience that is exactly the ledger `total_brl`.
        df['prejuizo_real_signed'] = df['total_brl']
        # magnitude-only (positive) when there is a loss, zero otherwise
        df['prejuizo_real'] = df['prejuizo_real_signed'].where(df['prejuizo_real_signed'] < 0, 0.0).abs()
    else:
        df['prejuizo_real_signed'] = 0.0
        df['prejuizo_real'] = 0.0
    if 'dinheiro_liberado' not in df.columns:
        df['dinheiro_liberado'] = 0.0
    # pending magnitude (positive) and signed version (negative to match ML UI semantics)
    # keep internal heuristics but they should NOT be presented to users as the
    # canonical "Prejuízo pendente". We'll keep the columns for debugging and
    # internal inspection but hide them from the main UI and exports.
    df['prejuizo_pendente_calc'] = (df['prejuizo_real'] - df['dinheiro_liberado']).clip(lower=0.0)
    df['prejuizo_pendente_signed'] = -df['prejuizo_pendente_calc']
    return df


def ensure_reviews_table():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS reviews (
            order_id TEXT PRIMARY KEY,
            reviewed INTEGER DEFAULT 0,
            reviewed_by TEXT,
            reviewed_at TEXT
        )
    ''')
    con.commit()
    con.close()


def get_reviews_map():
    ensure_reviews_table()
    con = sqlite3.connect(DB_PATH)
    df = pd.read_sql('SELECT order_id, reviewed, reviewed_by, reviewed_at FROM reviews', con)
    con.close()
    if df.empty:
        return {}
    return df.set_index('order_id').to_dict(orient='index')


def set_review(order_id: str, reviewed: bool, user: str = 'operator'):
    ensure_reviews_table()
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    now = datetime.now().isoformat()
    cur.execute('REPLACE INTO reviews (order_id, reviewed, reviewed_by, reviewed_at) VALUES (?,?,?,?)',
                (order_id, 1 if reviewed else 0, user if reviewed else None, now if reviewed else None))
    con.commit()
    con.close()


def create_xlsx_export(df: pd.DataFrame, path: Path, display_names: dict):
    # df already contains display columns and a 'Revisado' column
    try:
        # use context manager to ensure compatibility with newer pandas/openpyxl
        with pd.ExcelWriter(path, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Export')
            wb = writer.book
            ws = writer.sheets['Export']
        # header style
        header_font = Font(bold=True, color='000000')
        for col_idx, col in enumerate(df.columns, start=1):
            cell = ws.cell(row=1, column=col_idx)
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center')
            # column width
            max_len = max(df[col].astype(str).map(len).max() if not df.empty else 10, len(col))
            ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 4, 50)
            # currency formatting if column looks like currency
            if col.lower().find('r$')!=-1 or 'valor' in col.lower() or 'receita' in col.lower() or 'preço' in col.lower() or 'preco' in col.lower():
                for r in range(2, 2 + len(df)):
                    try:
                        # use a safe number format (avoid escape sequence warning)
                        ws.cell(row=r, column=col_idx).number_format = '#,##0.00'
                    except Exception:
                        pass
        return True, None
    except Exception as e:
        return False, str(e)

def save_action(order_id: str, user: str, action: str, note: str):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    # create actions table if it doesn't exist (simple audit table)
    cur.execute('''
        CREATE TABLE IF NOT EXISTS actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id TEXT,
            user TEXT,
            action TEXT,
            note TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        )
    ''')
    cur.execute('INSERT INTO actions (order_id, user, action, note) VALUES (?,?,?,?)', (order_id, user, action, note))
    con.commit()
    con.close()

def main():
    st.set_page_config(page_title='BI Devoluções - Protótipo', layout='wide')
    # small CSS polish
    st.markdown("""
    <style>
    .stApp { padding-top: 1rem; }
    .kpi { font-size: 22px; }
    table { border-collapse: collapse; }
    table th, table td { padding: 6px 8px; }
    </style>
    """, unsafe_allow_html=True)

    st.title('Controle de Devoluções — Protótipo')
    st.subheader('Painel para triagem, revisão e exportação de casos de devolução')

    months = get_months()
    col1, col2, col3 = st.columns([2,2,1])
    with col1:
        month = st.selectbox('Mês (YYYY‑MM)', options=[''] + months, index=0)
    with col2:
        sku = st.text_input('Filtro SKU (parte)')
    with col3:
        only_pending = st.checkbox('Apenas pendentes', value=True)

    # load reviews map
    reviews = get_reviews_map()

    df = load_financials(month if month else None, only_pending=only_pending, sku_filter=sku if sku else None)

    # helper: format currency BRL
    def fmt_brl(v):
        try:
            return f"R$ {v:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        except Exception:
            return str(v)

    def fmt_brl_signed(v):
        try:
            fv = float(v)
        except Exception:
            return str(v)
        if fv < 0:
            return f"-R$ {abs(fv):,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        return f"R$ {fv:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')

    # KPIs
    k1, k2, k3, k4 = st.columns(4)
    total_revenue = df['total_brl'].sum() if 'total_brl' in df.columns else 0.0
    total_orders = df['order_id'].nunique() if 'order_id' in df.columns else 0
    # prefer using computed signed pending prejudice when available (matches ML UI: negative values)
    if 'prejuizo_pendente_signed' in df.columns:
        total_pending = df['prejuizo_pendente_signed'].sum()
    else:
        # fall back to legacy raw column (positive magnitude) but show as negative to indicate loss
        total_pending = -df['_valor_pendente'].sum() if '_valor_pendente' in df.columns else 0.0
    top_skus = df.groupby('sku').agg(revenue=('total_brl','sum')).sort_values('revenue', ascending=False).head(5)

    k1.metric('Receita (seleção)', fmt_brl(total_revenue))
    k2.metric('Pedidos (seleção)', f'{total_orders:,}')
    k3.metric('Prejuízo pendente', fmt_brl_signed(total_pending))
    k4.metric('Top SKU (receita)', f"{top_skus.index[0] if not top_skus.empty else '-'}")

    st.markdown('---')
    st.subheader('Lista de Pedidos (amostra)')
    st.write('Tabela interativa — revise os pedidos e marque como "Revisado" quando concluído.')
    # prefer interactive dataframe only if pyarrow is available (st.dataframe imports pyarrow)
    sample = df.head(200).copy()
    # nice formatting for sample
    if 'data_venda' in sample.columns:
        sample['data_venda'] = sample['data_venda'].dt.strftime('%Y-%m-%d %H:%M:%S').fillna('')
    for col in ['total_brl', '_valor_passivel_extorno', '_valor_pendente', 'dinheiro_liberado', 'preco_unitario']:
        if col in sample.columns:
            sample[col] = sample[col].apply(lambda x: fmt_brl(x) if pd.notna(x) else '')

    # integrate 'Revisado' status from reviews table and prepare display-only DF
    display_map_ui = {
        'order_id':'Order ID',
        'data_venda':'Data da venda',
        'total_brl':'Total (R$)',
        '_valor_passivel_extorno':'Passível de estorno (R$)',
        'prejuizo_real_signed':'Prejuízo (R$)',
        'dinheiro_liberado':'Dinheiro liberado (R$)',
        'sku':'SKU',
        'preco_unitario':'Preço unitário (R$)',
        'unidades':'Unidades',
        'resultado':'Resultado'
    }

    if not sample.empty:
        sample_display = sample.copy()
        sample_display['Revisado'] = sample_display['order_id'].apply(lambda oid: '✅' if bool(reviews.get(str(oid), {}).get('reviewed', 0)) else '')
        sample_display['Revisado_por'] = sample_display['order_id'].apply(lambda oid: reviews.get(str(oid), {}).get('reviewed_by'))
        sample_display['Revisado_em'] = sample_display['order_id'].apply(lambda oid: reviews.get(str(oid), {}).get('reviewed_at'))
        # format prejuízo: we now use signed columns so negatives are shown (ML UI shows negative values)
        # prejuizo_real_signed and prejuizo_pendente_signed contain negative numbers when there's a loss
        if 'prejuizo_real_signed' in sample_display.columns:
            def fmt_signed_currency(x):
                try:
                    v = float(x)
                except Exception:
                    return x
                s = f"R$ {abs(v):,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
                if v < 0:
                    return f"<span class='neg'>-{s}</span>"
                return s
            sample_display['prejuizo_real_signed'] = sample_display['prejuizo_real_signed'].apply(fmt_signed_currency)
        if 'prejuizo_pendente_signed' in sample_display.columns:
            sample_display['prejuizo_pendente_signed'] = sample_display['prejuizo_pendente_signed'].apply(lambda v: f"<span class='neg'>-R$ {float(abs(v)):,.2f}</span>" if float(v) < 0 else f"R$ {float(v):,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.'))
        # restrict columns to the friendly display set and then rename
        cols_keep = [c for c in list(display_map_ui.keys()) if c in sample_display.columns]
        # append review metadata if present
        for extra in ['Revisado', 'Revisado_por', 'Revisado_em']:
            if extra in sample_display.columns:
                cols_keep.append(extra)
        sample_display = sample_display[cols_keep]
        sample_display.rename(columns={k:v for k,v in display_map_ui.items() if k in sample_display.columns}, inplace=True)
    else:
        sample_display = sample

    # render interactive table using client-side DataTables (no pyarrow required)
    st.markdown(render_interactive_table(sample_display, table_id='sample_tbl'), unsafe_allow_html=True)

    st.subheader('Marcar/Revisar pedido')
    with st.form('review_form'):
        order_id_in = st.text_input('Order ID para marcar/revisar')
        user_in = st.text_input('Usuário (quem revisou)', value='operator')
        reviewed_in = st.checkbox('Marcar como Revisado', value=False)
        submitted = st.form_submit_button('Salvar revisão')
        if submitted:
            if not order_id_in:
                st.error('Informe um Order ID')
            else:
                set_review(order_id_in, reviewed_in, user_in)
                st.success(('Marcado como Revisado' if reviewed_in else 'Desmarcado revisão') + ' para order_id=' + order_id_in)

    st.markdown('---')
    st.subheader('Detalhes do pedido')
    st.write('Abra o detalhe de um pedido para checar os campos que vieram no consolidado e comparar com os itens.')
    detail_id = st.text_input('Abrir detalhe por Order ID (cole aqui)')
    if detail_id:
        con = sqlite3.connect(DB_PATH)
        try:
            od = pd.read_sql('SELECT * FROM orders WHERE order_id = ?', con, params=(detail_id,))
            oi = pd.read_sql('SELECT * FROM order_items WHERE order_id = ?', con, params=(detail_id,))
        except Exception:
            od = pd.DataFrame()
            oi = pd.DataFrame()
        con.close()
        st.markdown('**Resumo (visão ML-like)**')
        if not od.empty:
            o = od.iloc[0]
            # Build a breakdown similar to the Mercado Livre detail panel
            breakdown = {
                'Preço do produto': o.get('receita_produtos_brl', 0.0),
                'Tarifa de venda total': o.get('tarifa_venda_impostos_brl', 0.0),
                'Tarifas de envio': o.get('tarifas_envio_brl', 0.0),
                'Cancelamentos e reembolsos': o.get('cancelamentos_reembolsos_brl', 0.0),
                'Dinheiro liberado': o.get('dinheiro_liberado', 0.0),
                'Total (nosso calculado)': o.get('total_brl', 0.0)
            }
            # pretty print the breakdown
            for k, v in breakdown.items():
                if v is None:
                    s = ''
                else:
                    s = fmt_brl_signed(v)
                st.write(f"{k}: ", s)
            # show internal pending heuristics inside a collapsed section with
            # an explicit explanation so users don't mistake it for the ML "Total"
            with st.expander('Valores internos (debug): _valor_pendente / _valor_passivel_extorno'):
                st.write('Estes valores são heurísticos internos sobre possíveis estornos/pendências. Não representam o "Total/Prejuízo" mostrado no painel do Mercado Livre.')
                st.write('_valor_pendente:', fmt_brl(o.get('_valor_pendente', 0.0)))
                st.write('_valor_passivel_extorno:', fmt_brl(o.get('_valor_passivel_extorno', 0.0)))
        else:
            st.info('Pedido não encontrado na tabela `orders`.')
        st.markdown('**Linha consolidada (orders)**')
        if not od.empty:
            st.json(od.to_dict(orient='records')[0])
        else:
            st.info('Pedido não encontrado na tabela `orders`.')

        st.markdown('**Itens (order_items)**')
        if not oi.empty:
            # render items as HTML table to avoid pyarrow
            oi_display = oi.copy()
            if 'preco_unitario' in oi_display.columns:
                oi_display['preco_unitario'] = oi_display['preco_unitario'].apply(lambda x: fmt_brl(x) if pd.notna(x) else '')
            st.markdown(render_interactive_table(oi_display, table_id='items_tbl'), unsafe_allow_html=True)
        else:
            st.info('Sem itens encontrados para este pedido.')

    st.markdown('---')
    st.subheader('Histórico de ações (últimas 50)')
    con = sqlite3.connect(DB_PATH)
    try:
        actions = pd.read_sql('SELECT id, order_id, user, action, note, created_at FROM actions ORDER BY id DESC LIMIT 50', con)
    except Exception:
        actions = pd.DataFrame()
    con.close()
    if not actions.empty:
        actions_display = actions.copy()
        st.markdown(render_interactive_table(actions_display, table_id='actions_tbl'), unsafe_allow_html=True)
    else:
        st.info('Nenhuma ação registrada ainda.')

    # Bulk review marking
    st.markdown('---')
    st.subheader('Marcar Revisado em Lote')
    st.write('Informe múltiplos Order IDs (separados por vírgula ou nova linha) e marque/desmarque como Revisado.')
    with st.form('bulk_review_form'):
        bulk_orders = st.text_area('Order IDs (ex: 2000..., 2001..., ou um por linha)')
        bulk_user = st.text_input('Usuário (quem revisa)', value='operator')
        bulk_reviewed = st.selectbox('Ação', ['Marcar como Revisado', 'Desmarcar Revisado'])
        bulk_submit = st.form_submit_button('Aplicar em lote')
        if bulk_submit:
            ids = [s.strip() for s in bulk_orders.replace(',', '\n').split('\n') if s.strip()]
            if not ids:
                st.error('Informe pelo menos um Order ID')
            else:
                for oid in ids:
                    set_review(oid, True if bulk_reviewed=='Marcar como Revisado' else False, bulk_user)
                st.success(f'{bulk_reviewed} aplicado a {len(ids)} pedidos')

    st.markdown('---')
    st.subheader('Relatórios e exportação')
    col_exp1, col_exp2 = st.columns(2)
    with col_exp1:
        if st.button('Exportar tabela atual para CSV'):
            out_dir = Path('reports')
            out_dir.mkdir(parents=True, exist_ok=True)
            out = out_dir / f'export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
            # include review columns
            export_df = df.copy()
            reviews_map = get_reviews_map()
            export_df['Revisado'] = export_df['order_id'].apply(lambda oid: bool(reviews_map.get(str(oid), {}).get('reviewed', 0)))
            export_df['Revisado_por'] = export_df['order_id'].apply(lambda oid: reviews_map.get(str(oid), {}).get('reviewed_by'))
            export_df['Revisado_em'] = export_df['order_id'].apply(lambda oid: reviews_map.get(str(oid), {}).get('reviewed_at'))
            export_df.to_csv(out, index=False, encoding='utf-8-sig')
            st.success(f'Export salvo em {out}')
    with col_exp2:
        if st.button('Exportar tabela atual para XLSX (formatado)'):
            out_dir = Path('reports')
            out_dir.mkdir(parents=True, exist_ok=True)
            out_x = out_dir / f'export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
            # build friendly display names (Português)
            display_map = {
                'order_id':'Order ID',
                'data_venda':'Data da venda',
                'total_brl':'Total (R$)',
                '_valor_passivel_extorno':'Passível de estorno (R$)',
                'dinheiro_liberado':'Dinheiro liberado (R$)',
                'sku':'SKU',
                'preco_unitario':'Preço unitário (R$)',
                'unidades':'Unidades',
                'resultado':'Resultado'
            }
            export_df = df.copy()
            reviews_map = get_reviews_map()
            export_df['Revisado'] = export_df['order_id'].apply(lambda oid: bool(reviews_map.get(str(oid), {}).get('reviewed', 0)))
            export_df['Revisado_por'] = export_df['order_id'].apply(lambda oid: reviews_map.get(str(oid), {}).get('reviewed_by'))
            export_df['Revisado_em'] = export_df['order_id'].apply(lambda oid: reviews_map.get(str(oid), {}).get('reviewed_at'))
            # rename columns to Portuguese friendly names where possible
            display_names = {c: display_map.get(c, c) for c in export_df.columns}
            export_df.rename(columns=display_names, inplace=True)
            ok, err = create_xlsx_export(export_df, out_x, display_names)
            if ok:
                st.success(f'Export XLSX salvo em {out_x}')
            else:
                st.error('Erro ao salvar XLSX: ' + (err or ''))

if __name__ == '__main__':
    main()
