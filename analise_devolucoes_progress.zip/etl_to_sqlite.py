"""ETL simples: agrega vários CSVs/planilhas exportadas do Mercado Livre
e grava em um banco SQLite para análises.

Uso:
  python etl_to_sqlite.py --input-dir C:\caminho\para\csvs --db ml_devolucoes.db

O script tenta normalizar nomes de colunas e tipos básicos.
"""

import argparse
import os
import pandas as pd
import sqlite3
from pathlib import Path


def normalize_columns(df):
    # padrão: lowercase, remove acentos simples, replace spaces
    cols = []
    for c in df.columns:
        s = str(c).lower()
        s = s.replace("ç", "c").replace("ã", "a").replace("á", "a").replace("à", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u")
        s = s.replace("º", "o").replace("#", "num").replace("%", "pct")
        s = s.replace(" ", "_").replace("/", "_").replace("\\\", "_")
        cols.append(s)
    df.columns = cols
    return df


def limpar_valor(valor):
    if pd.isna(valor):
        return 0.0
    if isinstance(valor, (int, float)):
        return float(valor)
    s = str(valor).replace("R$", "").replace("$", "").replace(" ", "").replace(".", "").replace(",", ".")
    try:
        return float(s)
    except Exception:
        return 0.0


def process_file(path, conn, table_name="devolucoes"):
    print(f"Processando: {path}")
    ext = Path(path).suffix.lower()
    if ext in (".xlsx", ".xls"):
        df = pd.read_excel(path, dtype=object)
    else:
        df = pd.read_csv(path, dtype=object, encoding="utf-8-sig")

    df = normalize_columns(df)

    # tentar detectar colunas monetárias e normalizar
    money_keys = [c for c in df.columns if any(x in c for x in ["valor", "preco", "preco_unitario", "total", "tarifa", "taxa", "frete"])]
    for c in money_keys:
        df[c] = df[c].apply(limpar_valor)

    # adiciona coluna de origem
    df["_source_file"] = os.path.basename(path)

    # grava no sqlite (append)
    df.to_sql(table_name, conn, if_exists="append", index=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--db", required=True)
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    db_path = Path(args.db)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(db_path))

    for file in sorted(input_dir.glob("*")):
        if file.suffix.lower() in (".csv", ".xlsx", ".xls"):
            try:
                process_file(file, conn)
            except Exception as e:
                print(f"Erro processando {file}: {e}")

    conn.close()
    print("Concluído. Base gerada em:", db_path)


if __name__ == "__main__":
    main()
